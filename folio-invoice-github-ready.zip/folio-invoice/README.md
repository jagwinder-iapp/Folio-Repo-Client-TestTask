# Folio — Invoice Studio

A compact, original browser-based invoice editor designed for a small business. Inspired by the clarity of HubSpot's invoice workflow and the customizability of Zoho Books, **without copying their interfaces**.

## Quick start

Requires Node.js 20+. No database, framework, or build step is required.

```bash
npm install
cp .env.example .env
npm start
```

Open **http://localhost:3000**. The invoice editor, saving, loading, and PDF printing work immediately. SMTP is optional.

Run tests with `npm test`.

## What works

- Desktop and mobile invoice editor, date selection, invoice numbers, business and customer details, notes.
- Add, edit and delete line items; USD line totals and a continuously updated invoice preview.
- Fixed USD discount, percentage tax, grand total. Each line rounds to cents, subtotal is summed, discount is subtracted, and tax is calculated and rounded on the discounted subtotal. Example: 2 × $50 − $10 + 10% tax = **$99.00**.
- Custom label/value fields, edit, hide/show, remove; only visible fields appear in the PDF and fields never affect calculations.
- Print / Save as PDF using the browser print dialog. Only invoice content prints.
- Save, update, list, and reload invoices through REST APIs, persisted in `data/invoices.json`.
- Optional SMTP email delivery, deliberately restricted to one controlled test inbox.
- Semantic form labels, focus styles, inline constraints, screen reader feedback for status notifications.

## Email setup

1. Create `.env` from `.env.example`.
2. Set `SMTP_HOST`, `SMTP_PORT`, `SMTP_SECURE`, `SMTP_USER`, `SMTP_PASS`, `SMTP_FROM`.
3. Set `EMAIL_TEST_RECIPIENT` to an inbox **you control**.
4. Run `npm install` to install the optional `nodemailer` package, then restart the server.
5. In the editor choose **Send invoice** and enter the *exact same* test address.

Email sending is disabled until configured; the endpoint rejects any other recipient with HTTP 403. Passwords are read server-side and never sent to the browser. The email contains an HTML and plaintext invoice summary; it does **not** attach a PDF. Browser printing provides the PDF export separately.

## Storage and API

| Method | Endpoint | Purpose |
| --- | --- | --- |
| `GET` | `/api/invoices` | List saved invoice summaries |
| `POST` | `/api/invoices` | Validate and save new invoice |
| `GET` | `/api/invoices/:id` | Retrieve invoice |
| `PUT` | `/api/invoices/:id` | Update invoice |
| `DELETE` | `/api/invoices/:id` | Delete invoice (API only) |
| `POST` | `/api/email` | SMTP to controlled recipient |

Storage is intentionally single-process JSON-file storage for the exercise; no database server to set up. Invoice updates write through a temporary file and rename. Do not treat this as production multiserver storage or an authenticated billing service.

## Design choices

**Design intent:** restrained, warm and editorial rather than generic dashboard overload. Navigation is limited to Invoice editor and Saved invoices. The editor is grouped into six natural sections, while the invoice itself stays visible on desktop. On mobile, Edit and Live preview become two accessible tabs. Invoice layout is print-safe with distinct information hierarchy.

**Reference influences:** HubSpot's invoice creation, line item, and send flow; Zoho Books' layout customization and visibility settings. References are conceptual, not cloned: https://knowledge.hubspot.com/invoices/create-invoices and https://www.zoho.com/in/books/help/settings/templates.html.

**Demo content:** Northstar Creative and Willow & Co. are fictional. The preview is seeded with plausible services to help reviewers judge the experience immediately. Click New invoice to reset.

**Rounding:** JavaScript cent-rounding uses `Math.round((value + Number.EPSILON)*100)/100`. For a production financial ledger, use decimal arithmetic or integer cents end to end.

**Security / constraints:** JSON request cap, server-side validation, HTML escaping on previews and email, controlled email recipient, no hardcoded credentials. Authentication and payments are omitted as allowed by the task. No deployment is configured.

## Evaluation walkthrough (video deliberately omitted)

1. Edit business and customer information; watch the preview update.
2. Add a line item and change quantity / rate; demonstrate instant totals.
3. Set quantity 2, price $50, discount $10, tax 10% to demonstrate $99.
4. Add and hide a custom field; verify it disappears from print.
5. Save the invoice. Visit Saved invoices, reload the browser, and reopen it.
6. Use Download PDF → Save as PDF.
7. With an SMTP test inbox configured, send a test email, then inspect delivery.

## AI use, time and incomplete work

AI assistance: GPT-6 helped implement application structure, UI, code, server, tests, and documentation. No copied third-party design assets were used. Human review remains recommended before submitting as your own work; be transparent about AI use because the exercise explicitly requests it.

Time spent: generated in a single implementation session; no independent wall-clock time log was captured, so no exact elapsed time is claimed. The interview exercise says to cap work at three hours.

Not completed: public GitHub upload, video walkthrough (intentionally deferred), hosted deployment, true server-generated PDF attachment, production-grade authentication and database, automated browser visual QA. The email pathway is implemented but delivery requires your SMTP configuration and an email account you control.

## Important difference between this source package and the Vercel review preview

This package is the original **Node.js/local JSON** implementation, using `server.js` and `data/invoices.json` on a single server. The live Vercel review preview at https://folio-invoice-studio-preview.vercel.app has since been adapted to serverless API routes and Vercel Blob. Do not deploy this Express-free local file-server implementation to Vercel expecting durable serverless filesystem writes: Vercel functions have an ephemeral filesystem. For a Vercel deployment, use a persistent database or Blob storage and configure its token using Vercel's managed project integration.

The public demo currently has no authentication. Do **not** submit real financial or customer data to a public unprotected demo. Sample data and demo recipient addresses are fictional/test only. Gmail SMTP credentials and Vercel Blob tokens must only be set as server-side environment variables, never in code or a public repository.

## Gmail SMTP demo example (local Node server)

1. Enable Gmail two-factor authentication and create a Google App Password under your Google Account settings (when eligible).
2. Copy `.env.example` to `.env` and enter `SMTP_HOST=smtp.gmail.com`, `SMTP_PORT=465`, `SMTP_SECURE=true`, your own `SMTP_USER`, `SMTP_PASS`, and `SMTP_FROM`.
3. Set `EMAIL_TEST_RECIPIENT=Zachary@yopmail.com` **only if you are authorized to use this public test inbox**. Public disposable inboxes are visible to others.
4. Run `npm install`, then `npm start`.
5. Send an invoice in the UI. An SMTP acceptance response means the server accepted the message; it does not prove final inbox delivery. Gmail has quotas and may restrict sign-in or SMTP.

## Interview disclosure

AI-assisted planning, UI implementation, code review, and documentation were used. Report your **actual personal time spent** before submission; the candidate must not invent a time figure. The video walkthrough requested by the exercise remains intentionally unrecorded at the user's direction. Other unfinished items: production authentication, real customer sending and delivery-event webhook verification, per-tenant access controls, and deployment-specific browser/mobile QA.
