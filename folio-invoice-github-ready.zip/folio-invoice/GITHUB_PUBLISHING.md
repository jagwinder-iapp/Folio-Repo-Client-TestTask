# Publishing to GitHub

1. Sign in to the connected GitHub account and create an **empty public repository** named `folio-invoice-studio` (do not initialize it with a README).
2. Unzip this source package and enter the `folio-invoice` directory.
3. Run:

```bash
git init
git branch -M main
git add .
git commit -m "Initial public invoice studio submission"
git remote add origin https://github.com/YOUR_USERNAME/folio-invoice-studio.git
git push -u origin main
```

Replace `YOUR_USERNAME` with the owner of the new repository. Never commit `.env`, App Passwords, API keys, or customer invoices. Check `git status` and the GitHub files before sharing the repository URL.

This ZIP is an **offline reference implementation**, not an export of the current Vercel Blob serverless deployment. See README for differences.
