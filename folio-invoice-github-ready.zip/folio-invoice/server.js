import http from 'node:http';
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { randomUUID } from 'node:crypto';

const root = path.dirname(fileURLToPath(import.meta.url));
const storagePath = path.join(root, 'data', 'invoices.json');
const pub = path.join(root, 'public');
try {
  const env = await fs.readFile(path.join(root, '.env'), 'utf8');
  for (const line of env.split(/\r?\n/)) {
    const match = line.match(/^\s*([A-Z_]+)\s*=\s*(.*)\s*$/);
    if (match && !process.env[match[1]]) process.env[match[1]] = match[2].replace(/^['"]|['"]$/g, '');
  }
} catch {}

const port = Number(process.env.PORT || 3000);
const respond = (res, status, data) => {
  const body = JSON.stringify(data);
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff' });
  res.end(body);
};
const money = x => Math.round((Number(x) + Number.EPSILON) * 100) / 100;
export function totals(invoice) {
  const items = invoice.items.map(item => money(Number(item.quantity) * Number(item.price)));
  const subtotal = money(items.reduce((sum, v) => sum + Math.round(v * 100), 0) / 100);
  const discount = money(Number(invoice.discount || 0));
  const tax = money(money(subtotal - discount) * (Number(invoice.taxRate || 0) / 100));
  return { lineTotals: items, subtotal, discount, taxable: money(subtotal - discount), tax, total: money(subtotal - discount + tax) };
}
function validate(invoice) {
  if (!invoice || typeof invoice !== 'object') return 'Invalid invoice.';
  if (!String(invoice.number || '').trim()) return 'Invoice number is required.';
  if (!String(invoice.business?.name || '').trim()) return 'Business name is required.';
  if (!String(invoice.customer?.name || '').trim()) return 'Customer name is required.';
  if (!Array.isArray(invoice.items) || !invoice.items.length) return 'Add at least one line item.';
  if (!/^\d{4}-\d{2}-\d{2}$/.test(invoice.issueDate || '') || !/^\d{4}-\d{2}-\d{2}$/.test(invoice.dueDate || '')) return 'Valid issue and due dates are required.';
  if (invoice.dueDate < invoice.issueDate) return 'Due date cannot be before the issue date.';
  if (invoice.items.length > 100 || (invoice.fields || []).length > 100) return 'Too many items or custom fields.';
  for (const item of invoice.items) {
    if (!String(item.description || '').trim()) return 'Each line item needs a description.';
    for (const key of ['quantity', 'price']) if (!Number.isFinite(Number(item[key])) || Number(item[key]) < 0 || item[key] === '') return 'Quantities and prices must be non-negative numbers.';
  }
  if (![invoice.discount ?? 0, invoice.taxRate ?? 0].every(v => v !== '' && Number.isFinite(Number(v)) && Number(v) >= 0)) return 'Discount and tax must be non-negative numbers.';
  if (Number(invoice.taxRate) > 100) return 'Tax rate cannot exceed 100%.';
  if (money(invoice.discount || 0) > totals({...invoice, discount: 0}).subtotal) return 'Discount cannot exceed subtotal.';
  if (!Array.isArray(invoice.fields || []) || (invoice.fields || []).some(f => typeof f.label !== 'string' || typeof f.value !== 'string')) return 'Invalid custom fields.';
  return null;
}
async function list() { try { return JSON.parse(await fs.readFile(storagePath, 'utf8')); } catch (e) { if(e.code === 'ENOENT') return []; throw e; } }
let writeQueue = Promise.resolve();
function persist(next) { writeQueue = writeQueue.catch(() => {}).then(async () => { await fs.mkdir(path.dirname(storagePath), { recursive: true }); const tmp = storagePath + '.tmp'; await fs.writeFile(tmp, JSON.stringify(next, null, 2)); await fs.rename(tmp, storagePath); }); return writeQueue; }
async function bodyJSON(req) { let payload=''; for await (const c of req) { payload += c; if(payload.length > 1_000_000) throw new Error('Payload too large.'); } return JSON.parse(payload || '{}'); }
function esc(s) { return String(s ?? '').replace(/[&<>"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch])); }
const cash = v => new Intl.NumberFormat('en-US', { style:'currency', currency:'USD' }).format(v);
const emailHTML = (invoice) => {const t=totals(invoice);return `<div style="font:16px/1.6 Arial,sans-serif;max-width:580px;margin:auto;color:#192327"><h1 style="font-size:26px">Invoice ${esc(invoice.number)}</h1><p>Hi ${esc(invoice.customer.name)},</p><p>Please find the details of your invoice from <b>${esc(invoice.business.name)}</b> below.</p><table style="width:100%;border-collapse:collapse">${invoice.items.map((i,n)=>`<tr><td style="padding:12px 0;border-bottom:1px solid #ddd">${esc(i.description)}</td><td style="text-align:right">${cash(t.lineTotals[n])}</td></tr>`).join('')}</table><p style="font-size:21px"><b>Total due: ${cash(t.total)}</b></p><p>Due ${esc(invoice.dueDate)}</p><p>${esc(invoice.notes || '')}</p><p>Thank you,<br>${esc(invoice.business.name)}</p></div>`;};

const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
    if (url.pathname === '/api/invoices' && req.method === 'GET') {
      const invoices = await list(); return respond(res,200,invoices.map(i=>({id:i.id,number:i.number,customer:i.customer?.name,issueDate:i.issueDate,dueDate:i.dueDate,total:totals(i).total,updatedAt:i.updatedAt})).sort((a,b)=>b.updatedAt.localeCompare(a.updatedAt)));
    }
    if (url.pathname === '/api/invoices' && req.method === 'POST') {
      const payload=await bodyJSON(req), error=validate(payload); if(error) return respond(res,422,{error});
      const invoices=await list(); const stored={...payload,id:randomUUID(),updatedAt:new Date().toISOString()}; invoices.push(stored); await persist(invoices);return respond(res,201,stored);
    }
    const match = url.pathname.match(/^\/api\/invoices\/([\w-]+)$/);
    if(match && req.method === 'GET') { const item=(await list()).find(i=>i.id===match[1]); return item?respond(res,200,item):respond(res,404,{error:'Invoice not found.'}); }
    if(match && req.method === 'PUT') { const payload=await bodyJSON(req),error=validate(payload);if(error)return respond(res,422,{error});const arr=await list(),index=arr.findIndex(i=>i.id===match[1]);if(index<0)return respond(res,404,{error:'Invoice not found.'});arr[index]={...payload,id:match[1],updatedAt:new Date().toISOString()};await persist(arr);return respond(res,200,arr[index]); }
    if(match && req.method === 'DELETE') {const arr=await list(),filtered=arr.filter(i=>i.id!==match[1]); if(filtered.length===arr.length)return respond(res,404,{error:'Invoice not found.'});await persist(filtered);return respond(res,200,{ok:true});}
    if(url.pathname === '/api/email' && req.method === 'POST') {
      const { invoice, recipient } = await bodyJSON(req); const err=validate(invoice);if(err)return respond(res,422,{error:err});
      const allowed=(process.env.EMAIL_TEST_RECIPIENT || '').trim().toLowerCase();
      if(!allowed || recipient?.trim().toLowerCase() !== allowed)return respond(res,403,{error:'Email is limited to the configured EMAIL_TEST_RECIPIENT test address.'});
      if(!process.env.SMTP_HOST || !process.env.SMTP_USER || !process.env.SMTP_PASS)return respond(res,503,{error:'Email is not configured. Set SMTP variables in .env.'});
      let nodemailer;try { ({default:nodemailer}=await import('nodemailer')); }catch {return respond(res,503,{error:'Install optional nodemailer dependency with npm install to enable email.'});}
      const transport=nodemailer.createTransport({host:process.env.SMTP_HOST,port:Number(process.env.SMTP_PORT||587),secure:process.env.SMTP_SECURE==='true',auth:{user:process.env.SMTP_USER,pass:process.env.SMTP_PASS}});
      await transport.sendMail({from:process.env.SMTP_FROM || process.env.SMTP_USER,to:allowed,subject:`Invoice ${invoice.number} from ${invoice.business.name}`,html:emailHTML(invoice),text:`Invoice ${invoice.number}\nFrom: ${invoice.business.name}\nTo: ${invoice.customer.name}\nTotal due: ${cash(totals(invoice).total)}\nDue: ${invoice.dueDate}\n${invoice.notes||''}`});
      return respond(res,200,{ok:true});
    }
    if(req.method !== 'GET' && req.method !== 'HEAD')return respond(res,405,{error:'Method not allowed.'});
    const paths={'/':'index.html','/index.html':'index.html','/style.css':'style.css','/app.js':'app.js'};
    const name=paths[url.pathname]; if(!name) return respond(res,404,{error:'Not found.'});
    const types={'.html':'text/html; charset=utf-8','.css':'text/css; charset=utf-8','.js':'text/javascript; charset=utf-8'};
    const data=await fs.readFile(path.join(pub,name));res.writeHead(200,{'Content-Type':types[path.extname(name)],'X-Content-Type-Options':'nosniff'});res.end(req.method === 'HEAD'?undefined:data);
  } catch(e) { console.error(e);respond(res,e instanceof SyntaxError?400:500,{error:e instanceof SyntaxError?'Invalid JSON.':e.message || 'Unexpected server error.'}); }
});
if (process.env.NODE_ENV !== 'test' && !process.env.NODE_TEST_CONTEXT) server.listen(port,()=>console.log(`Folio Invoice Studio → http://localhost:${port}`));
export {server,validate};
